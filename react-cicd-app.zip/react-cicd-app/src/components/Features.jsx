export function Features() {
  const items = [
    { title: 'طراحی تمیز', desc: 'طراحی مینیمال با تمرکز بر خوانایی و تجربه کاربری.' },
    { title: 'TailwindCSS', desc: 'استایل‌دهی سریع، قابل‌گسترش و ثابت در کل پروژه.' },
    { title: 'Vite', desc: 'ابزار ساخت سریع با HMR و خروجی اپتیمایز.' },
    { title: 'انیمیشن نرم', desc: 'استفاده از framer-motion برای انیمیشن‌های روان.' },
  ]
  return (
    <section id="features" className="container pb-16">
      <h2 className="text-2xl font-extrabold text-slate-900 mb-6">ویژگی‌های کلیدی</h2>
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {items.map((it, i) => (
          <div key={i} className="card p-6">
            <div className="text-lg font-bold text-slate-900">{it.title}</div>
            <p className="mt-2 text-slate-700 leading-7">{it.desc}</p>
          </div>
        ))}
      </div>
    </section>
  )
}
