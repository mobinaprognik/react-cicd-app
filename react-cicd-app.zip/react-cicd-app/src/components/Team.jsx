export function Team() {
  const members = [
    { name: 'زهره', role: 'Frontend Designer', bio: 'جزئیات دقیق، سادگی و زیبایی.' },
    { name: 'مبینا', role: 'React Developer', bio: 'کدنویسی تمیز و ماژولار.' },
  ]
  return (
    <section id="team" className="container pb-20">
      <h2 className="text-2xl font-extrabold text-slate-900 mb-6">تیم</h2>
      <div className="grid sm:grid-cols-2 gap-6">
        {members.map((m, i) => (
          <div key={i} className="card p-6 flex items-start gap-4">
            <div className="h-14 w-14 rounded-2xl bg-slate-900 text-white grid place-content-center text-lg font-bold">
              {m.name[0]}
            </div>
            <div>
              <div className="text-lg font-bold text-slate-900">{m.name}</div>
              <div className="text-sm text-slate-600">{m.role}</div>
              <p className="mt-2 text-slate-700 leading-7">{m.bio}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}
