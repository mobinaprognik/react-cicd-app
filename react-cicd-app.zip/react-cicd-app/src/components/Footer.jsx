export function Footer() {
  return (
    <footer id="contact" className="border-t border-slate-200 py-10">
      <div className="container text-sm text-slate-600 flex items-center justify-between">
        <div>© {new Date().getFullYear()} زهره × مبینا</div>
        <a href="mailto:hello@example.com" className="hover:text-slate-900">hello@example.com</a>
      </div>
    </footer>
  )
}
