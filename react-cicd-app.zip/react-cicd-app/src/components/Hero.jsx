import { motion } from 'framer-motion'

export function Hero() {
  return (
    <section className="container pt-16 pb-20">
      <div className="grid md:grid-cols-2 gap-8 items-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h1 className="text-4xl md:text-5xl font-extrabold leading-tight text-slate-900">
            یک رابط کاربری <span className="text-sky-600">مدرن</span>،
            با امضای <span className="text-indigo-600">زهره</span> و <span className="text-indigo-600">مبینا</span> ✨
          </h1>
          <p className="mt-4 text-slate-700 leading-8">
            این پروژه نمونه برای تست CI/CD روی GitLab است. همه‌چیز با Vite + React + Tailwind ساخته شده
            تا سبک، سریع و حرفه‌ای باشد.
          </p>
          <div className="mt-6 flex gap-3">
            <a className="btn-primary" href="#features">شروع کنید</a>
            <a className="inline-flex items-center justify-center rounded-xl px-4 py-2 text-sm font-semibold border border-slate-300 hover:bg-white/70">
              مستندات
            </a>
          </div>
        </motion.div>
        <motion.div
          className="card p-6"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.1 }}
        >
          <div className="aspect-video rounded-xl bg-gradient-to-br from-indigo-200 to-sky-200 grid place-content-center text-slate-800">
            <div className="text-center">
              <div className="text-5xl font-black">CI/CD</div>
              <div className="mt-2 text-sm opacity-70">GitLab • Docker • VPS</div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
