export function Navbar() {
  return (
    <header className="sticky top-0 z-40 backdrop-blur bg-white/60 border-b border-slate-200">
      <nav className="container flex items-center justify-between py-3">
        <div className="flex items-center gap-2">
          <span className="h-10 w-10 rounded-2xl bg-slate-900 text-white grid place-content-center font-bold">ZM</span>
          <span className="font-extrabold text-slate-900">زهره × مبینا</span>
        </div>
        <div className="hidden md:flex items-center gap-6 text-slate-700">
          <a href="#features" className="hover:text-slate-950">ویژگی‌ها</a>
          <a href="#team" className="hover:text-slate-950">تیم</a>
          <a href="#contact" className="btn-primary">ارتباط</a>
        </div>
      </nav>
    </header>
  )
}
